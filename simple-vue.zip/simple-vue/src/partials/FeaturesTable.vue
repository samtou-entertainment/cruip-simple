<template>
  <section>
    <div class="max-w-6xl mx-auto px-4 sm:px-6">
      <div class="pt-12 md:pt-20">

        <!-- Section header -->
        <div class="pb-12">
          <h2 class="h2">Features</h2>
        </div>

        <!-- Table -->
        <div class="overflow-x-auto">
          <table class="table-auto w-full border-b border-gray-200">
            <!-- Table header -->
            <thead>
              <tr class="text-base sm:text-lg border-t border-gray-200">
                <th class="text-bold text-left pr-2 py-4 min-w-48">Breakdown of features</th>
                <th class="text-bold text-center px-2 py-4">Starter</th>
                <th class="text-bold text-center px-2 py-4">Premium</th>
                <th class="text-bold text-center px-2 py-4">Agency</th>
                <th class="text-bold text-center pl-2 py-4">Enterprise</th>
              </tr>
            </thead>
            <!-- Table body -->
            <tbody>
              <!-- Row -->
              <tr class="border-t border-gray-200">
                <td class="text-sm sm:text-base pr-2 py-4">
                  <div class="font-medium underline">Unlimited viewers</div>
                  <div class="text-gray-600">Lorem ipsum dolor sit amet, consectetur adipiscing elit</div>
                </td>
                <td class="text-sm px-2 py-4 text-center font-medium">
                  <svg class="w-3 h-3 fill-current text-green-500 inline-flex" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z" />
                  </svg>
                </td>
                <td class="text-sm px-2 py-4 text-center font-medium">
                  <svg class="w-3 h-3 fill-current text-green-500 inline-flex" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z" />
                  </svg>
                </td>
                <td class="text-sm px-2 py-4 text-center font-medium">
                  <svg class="w-3 h-3 fill-current text-green-500 inline-flex" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z" />
                  </svg>
                </td>
                <td class="text-sm pl-2 py-4 text-center font-medium">
                  <svg class="w-3 h-3 fill-current text-green-500 inline-flex" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z" />
                  </svg>
                </td>
              </tr>
              <!-- Row -->
              <tr class="border-t border-gray-200">
                <td class="text-sm sm:text-base pr-2 py-4">
                  <div class="font-medium underline">Team members</div>
                  <div class="text-gray-600">Excepteur sint occaecat cupidatat non proident</div>
                </td>
                <td class="text-sm px-2 py-4 text-center font-medium">3</td>
                <td class="text-sm px-2 py-4 text-center font-medium">Unlimited</td>
                <td class="text-sm px-2 py-4 text-center font-medium">Unlimited</td>
                <td class="text-sm pl-2 py-4 text-center font-medium">Unlimited</td>
              </tr>
              <!-- Row -->
              <tr class="border-t border-gray-200">
                <td class="text-sm sm:text-base pr-2 py-4">
                  <div class="font-medium underline">Projects</div>
                  <div class="text-gray-600">Culpa qui officia deserunt mollit anim</div>
                </td>
                <td class="text-sm px-2 py-4 text-center font-medium">3</td>
                <td class="text-sm px-2 py-4 text-center font-medium">20</td>
                <td class="text-sm px-2 py-4 text-center font-medium">50</td>
                <td class="text-sm pl-2 py-4 text-center font-medium">Unlimited</td>
              </tr>
              <!-- Row -->
              <tr class="border-t border-gray-200">
                <td class="text-sm sm:text-base pr-2 py-4">
                  <div class="font-medium underline">Dedicated support</div>
                  <div class="text-gray-600">Excepteur sint occaecat cupidatat non proident</div>
                </td>
                <td class="text-sm px-2 py-4 text-center font-medium">
                  <svg class="w-3 h-3 fill-current text-green-500 inline-flex" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z" />
                  </svg>
                </td>
                <td class="text-sm px-2 py-4 text-center font-medium">
                  <svg class="w-3 h-3 fill-current text-green-500 inline-flex" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z" />
                  </svg>
                </td>
                <td class="text-sm px-2 py-4 text-center font-medium">
                  <svg class="w-3 h-3 fill-current text-green-500 inline-flex" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z" />
                  </svg>
                </td>
                <td class="text-sm pl-2 py-4 text-center font-medium">
                  <svg class="w-3 h-3 fill-current text-green-500 inline-flex" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z" />
                  </svg>
                </td>
              </tr>
              <!-- Row -->
              <tr class="border-t border-gray-200">
                <td class="text-sm sm:text-base pr-2 py-4">
                  <div class="font-medium underline">Private projects</div>
                  <div class="text-gray-600">Lorem ipsum dolor sit amet, consectetur adipiscing elit</div>
                </td>
                <td class="text-sm px-2 py-4 text-center font-medium">
                  <svg class="w-3 h-3 fill-current text-gray-400 opacity-75 inline-flex" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.72 1.293a1 1 0 00-1.415 0L6.012 4.586 2.72 1.293a1 1 0 00-1.414 1.414L4.598 6 1.305 9.293a1 1 0 101.414 1.414l3.293-3.293 3.293 3.293a1 1 0 001.414-1.414L7.426 6l3.293-3.293a1 1 0 000-1.414z" />
                  </svg>
                </td>
                <td class="text-sm px-2 py-4 text-center font-medium">
                  <svg class="w-3 h-3 fill-current text-green-500 inline-flex" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z" />
                  </svg>
                </td>
                <td class="text-sm px-2 py-4 text-center font-medium">
                  <svg class="w-3 h-3 fill-current text-green-500 inline-flex" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z" />
                  </svg>
                </td>
                <td class="text-sm pl-2 py-4 text-center font-medium">
                  <svg class="w-3 h-3 fill-current text-green-500 inline-flex" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z" />
                  </svg>
                </td>
              </tr>
              <!-- Row -->
              <tr class="border-t border-gray-200">
                <td class="text-sm sm:text-base pr-2 py-4">
                  <div class="font-medium underline">Public repositories</div>
                  <div class="text-gray-600">Ut enim ad minim veniam quis nostrud exercitation ullamco</div>
                </td>
                <td class="text-sm px-2 py-4 text-center font-medium">
                  <svg class="w-3 h-3 fill-current text-gray-400 opacity-75 inline-flex" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.72 1.293a1 1 0 00-1.415 0L6.012 4.586 2.72 1.293a1 1 0 00-1.414 1.414L4.598 6 1.305 9.293a1 1 0 101.414 1.414l3.293-3.293 3.293 3.293a1 1 0 001.414-1.414L7.426 6l3.293-3.293a1 1 0 000-1.414z" />
                  </svg>
                </td>
                <td class="text-sm px-2 py-4 text-center font-medium">
                  <svg class="w-3 h-3 fill-current text-gray-400 opacity-75 inline-flex" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.72 1.293a1 1 0 00-1.415 0L6.012 4.586 2.72 1.293a1 1 0 00-1.414 1.414L4.598 6 1.305 9.293a1 1 0 101.414 1.414l3.293-3.293 3.293 3.293a1 1 0 001.414-1.414L7.426 6l3.293-3.293a1 1 0 000-1.414z" />
                  </svg>
                </td>
                <td class="text-sm px-2 py-4 text-center font-medium">
                  <svg class="w-3 h-3 fill-current text-green-500 inline-flex" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z" />
                  </svg>
                </td>
                <td class="text-sm pl-2 py-4 text-center font-medium">
                  <svg class="w-3 h-3 fill-current text-green-500 inline-flex" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z" />
                  </svg>
                </td>
              </tr>
              <!-- Row -->
              <tr class="border-t border-gray-200">
                <td class="text-sm sm:text-base pr-2 py-4">
                  <div class="font-medium underline">Account manager</div>
                  <div class="text-gray-600">Condimentum id venenatis a condimentum vitae</div>
                </td>
                <td class="text-sm px-2 py-4 text-center font-medium">
                  <svg class="w-3 h-3 fill-current text-gray-400 opacity-75 inline-flex" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.72 1.293a1 1 0 00-1.415 0L6.012 4.586 2.72 1.293a1 1 0 00-1.414 1.414L4.598 6 1.305 9.293a1 1 0 101.414 1.414l3.293-3.293 3.293 3.293a1 1 0 001.414-1.414L7.426 6l3.293-3.293a1 1 0 000-1.414z" />
                  </svg>
                </td>
                <td class="text-sm px-2 py-4 text-center font-medium">
                  <svg class="w-3 h-3 fill-current text-gray-400 opacity-75 inline-flex" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.72 1.293a1 1 0 00-1.415 0L6.012 4.586 2.72 1.293a1 1 0 00-1.414 1.414L4.598 6 1.305 9.293a1 1 0 101.414 1.414l3.293-3.293 3.293 3.293a1 1 0 001.414-1.414L7.426 6l3.293-3.293a1 1 0 000-1.414z" />
                  </svg>
                </td>
                <td class="text-sm px-2 py-4 text-center font-medium">
                  <svg class="w-3 h-3 fill-current text-gray-400 opacity-75 inline-flex" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.72 1.293a1 1 0 00-1.415 0L6.012 4.586 2.72 1.293a1 1 0 00-1.414 1.414L4.598 6 1.305 9.293a1 1 0 101.414 1.414l3.293-3.293 3.293 3.293a1 1 0 001.414-1.414L7.426 6l3.293-3.293a1 1 0 000-1.414z" />
                  </svg>
                </td>
                <td class="text-sm pl-2 py-4 text-center font-medium">
                  <svg class="w-3 h-3 fill-current text-green-500 inline-flex" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z" />
                  </svg>
                </td>
              </tr>
            </tbody>
          </table>
        </div>

      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: 'FeaturesTable',
}
</script>