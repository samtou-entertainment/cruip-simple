# CHANGELOG.md

## [1.9.0] - 2022-07-15

- Replace Sass with CSS files

## [1.8.0] - 2022-07-11

- Update dependencies

## [1.7.0] - 2022-07-11

- Several minor changes

## [1.6.0] - 2022-01-24

- Minor changes

## [1.5.0] - 2022-01-13

- Minor changes

## [1.4.0] - 2021-12-13

- Update Tailwind 3
- Several improvements

## [1.3.0] - 2021-10-20

Update dependencies

## [1.2.1] - 2021-05-07

Fix images paths

## [1.2.0] - 2021-05-06

Upgrade to Vue 3 and Vue Router 4

## [1.1.0] - 2021-05-06

Update dependencies and use Tailwind 2

## [1.0.1] - 2021-05-06

Several minor changes

## [1.0.0] - 2020-10-19

First release