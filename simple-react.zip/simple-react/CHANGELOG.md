# CHANGELOG.md

## [1.7.0] - 2022-07-15

- Replace Sass with CSS files

## [1.6.0] - 2022-07-11

- Update dependencies
- Update React to v18

## [1.5.0] - 2022-01-25

- Replace CRA (Create React App) with Vite
- Remove Craco
- Update dependencies

## [1.4.0] - 2022-01-13

- Minor changes

## [1.3.0] - 2021-12-13

- Update Tailwind 3
- Several improvements

## [1.2.0] - 2021-10-20

Update dependencies and remove some

## [1.1.2] - 2021-09-09

Fix minor issue with FeaturesHome component

## [1.1.1] - 2021-08-19

Fix mobile menu issue

## [1.1.0] - 2021-05-05

Update dependencies and use Tailwind 2

## [1.0.1] - 2021-05-05

Several minor changes

## [1.0.0] - 2020-10-19

First release
